/*
noMeiryoUI (C) 2005,2012-2016 Tatsuhiko Shoji
The sources for noMeiryoUI are distributed under the MIT open source license
*/
#ifndef UTIL_H
#define UTIL_H

#include <stdlib.h>
#include <windows.h>
#include <windowsx.h>
#include <vector>
#include "TWR/tstring.h"

#define PRESET_SECTION "PRESET"

extern bool WIN8_SIZE;
extern std::vector<tstring> langResource;
/** �t�H���g��(Windows 8.x) */
extern std::vector<tstring> fontFaces8;
/** �t�H���g�T�C�Y(Windows 8.x) */
extern std::vector<int> fontSizes8;
/** �t�H���g��(Windows 10) */
extern std::vector<tstring> fontFaces10;
/** �t�H���g�T�C�Y(Windows 8.x) */
extern std::vector<int> fontSizes10;


int getFontPointInt(LOGFONT *font, HWND hWnd);
double getFontPoint(LOGFONT *font, HWND hWnd);
void readResourceFile(TCHAR *file);
int readFontResource8(TCHAR *file);
int readFontResource10(TCHAR *file);
int setFontResourceJa8(void);
int setFontResourceJa10(void);

#endif
